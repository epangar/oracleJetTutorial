var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define(["require", "exports", "../accUtils", "knockout", "ojs/ojknockout-keyset", "ojs/ojrestdataprovider", "ojs/ojselectsingle", "ojs/ojchart", "ojs/ojlabel", "ojs/ojlistview", "ojs/ojavatar", "ojs/ojdialog", "ojs/ojinputtext", "demo-update-item/loader"], function (require, exports, AccUtils, ko, ojknockout_keyset_1, ojrestdataprovider_1) {
    "use strict";
    const emptyItem = {
        id: 0,
        name: '',
        short_desc: '',
        price: 0,
        quantity: 0,
        quantity_shipped: 0,
        quantity_instock: 0,
        activity_id: 0,
        image: ''
    };
    class DashboardViewModel {
        constructor() {
            //  Fields for delete button and update dialog, among others
            this.selectedRow = ko.observable();
            this.inputImageFile = 'css/images/product_images/jet_logo_256.png';
            this.keyAttributes = "id";
            this.activityKey = 3;
            this.restServerURLActivities = "https://apex.oracle.com/pls/apex/oraclejet/lp/activities/";
            this.restServerURLItems = "https://apex.oracle.com/pls/apex/oraclejet/lp/activities/" + this.activityKey + "/items/";
            // Observables for Activities
            this.selectedActivity = new ojknockout_keyset_1.ObservableKeySet();
            this.activitySelected = ko.observable(false);
            this.firstSelectedActivity = ko.observable();
            this.selectedActivityIds = ko.observable();
            // Observables for Activity Items
            this.itemSelected = ko.observable(false);
            this.selectedKeyItem = ko.observable();
            this.firstSelectedItem = ko.observable();
            this.selectedActivityChanged = (event) => {
                /**
                *  If no items are selected then the firstSelectedItem property  returns an object
                *  with both key and data properties set to null.
                */
                //  debugger
                let itemContext = event.detail.value.data;
                if (itemContext != null) {
                    // debugger
                    // If selection, populate and display list
                    // Hide currently-selected activity item
                    this.activitySelected(false);
                    //let itemsArray = itemContext.items;
                    //this.itemsDataProvider.data = itemsArray;
                    // Set List View properties
                    this.activityKey = event.detail.value.data.id;
                    this.restServerURLItems = "https://apex.oracle.com/pls/apex/oraclejet/lp/activities/" + this.activityKey + "/items/";
                    this.itemsDataProvider = new ojrestdataprovider_1.RESTDataProvider({
                        keyAttributes: this.keyAttributes,
                        url: this.restServerURLItems,
                        transforms: {
                            fetchFirst: {
                                request: (options) => __awaiter(this, void 0, void 0, function* () {
                                    // debugger
                                    const url = new URL(options.url);
                                    const { size, offset } = options.fetchParameters;
                                    url.searchParams.set("limit", String(size));
                                    url.searchParams.set("offset", String(offset));
                                    return new Request(url.href);
                                }),
                                response: ({ body }) => __awaiter(this, void 0, void 0, function* () {
                                    // debugger
                                    const { items, totalSize, hasMore } = body;
                                    return { data: items, totalSize, hasMore };
                                }),
                            },
                        },
                    });
                    this.activitySelected(true);
                    this.itemSelected(false);
                    this.selectedKeyItem();
                    this.selectedData();
                }
                else {
                    // debugger
                    // If deselection, hide list      
                    this.activitySelected(false);
                    this.itemSelected(false);
                }
            };
            this.showCreateDialog = (event) => {
                //Observable de useCase
                this.useCase('create');
                //Inicializar observable de currentItem
                this.currentItem(Object.assign({}, emptyItem));
                let x = document.getElementById("createDialog");
                let y = x;
                y.open();
            };
            this.createItem = (event) => __awaiter(this, void 0, void 0, function* () {
                let a = Number(this.quantity_instock());
                let b = Number(this.quantity_shipped());
                this.quantity = a + b;
                const row = {
                    name: this.itemName(),
                    short_desc: this.short_desc(),
                    price: this.price(),
                    quantity_instock: this.quantity_instock(),
                    quantity_shipped: this.quantity_shipped(),
                    quantity: this.quantity,
                    activity_id: this.activityKey,
                    image: this.inputImageFile
                };
                const request = new Request(this.restServerURLItems, {
                    headers: new Headers({
                        "Content-type": "application/json; charset=UTF-8",
                    }),
                    body: JSON.stringify(row),
                    method: "POST"
                });
                const response = yield fetch(request);
                const addedRow = yield response.json();
                const addedRowKey = addedRow[this.keyAttributes];
                const addedRomMetaData = { key: addedRowKey };
                this.itemsDataProvider.mutate({
                    add: {
                        data: [addedRow],
                        keys: new Set([addedRowKey]),
                        metadata: [addedRomMetaData]
                    }
                });
                this.itemsDataProvider.refresh();
                //close
                let x = document.getElementById("createDialog");
                let y = x;
                y.close();
            });
            this.showEditDialog = (event) => {
                this.inputItemName(this.selectedData().name);
                this.inputPrice(this.selectedData().price);
                this.inputShortDescription(this.selectedData().short_desc);
                //Observable de useCase
                this.useCase('update');
                /*
                type Item = {
                  id: number;
                  name: string;
                  short_desc: string;
                  price: number;
                  quantity: number;
                  quantity_shipped: number;
                  quantity_instock: number;
                  activity_id: number;
                  image: string;
                }*/
                //Observable of currentItem
                debugger;
                //this.currentItem.id(1)
                // this.currentItem({
                //   id: this.selectedData().id,
                //   name: this.selectedData().name,
                //   short_desc: this.selectedData().short_desc,
                //   price: this.selectedData().price,
                //   quantity: this.selectedData().quantity,
                //   quantity_shipped: this.selectedData().quantity_shipped,
                //   quantity_instock: this.selectedData().quantity_instock,
                //   activity_id: this.selectedData().activity_id,
                //   image: this.selectedData().image,
                // })
                document.getElementById("editDialog").open();
            };
            this.updateItemSubmit = (event) => __awaiter(this, void 0, void 0, function* () {
                const currentRow = this.selectedRow;
                if (currentRow != null) {
                    debugger;
                    this.activityKey;
                    const row = {
                        itemId: this.selectedData().id,
                        name: this.inputItemName(),
                        price: this.inputPrice(),
                        short_desc: this.inputShortDescription()
                    };
                    const request = new Request(`${this.restServerURLItems}${this.selectedData().id}`, {
                        headers: new Headers({
                            "Content-type": "application/json; charset=UTF-8",
                        }),
                        body: JSON.stringify(row),
                        method: "PUT",
                    });
                    const response = yield fetch(request);
                    const updatedRow = yield response.json();
                    const updatedRowKey = this.selectedData().id;
                    const updatedRowMetaData = { key: updatedRowKey };
                    this.itemsDataProvider.mutate({
                        update: {
                            data: [updatedRow],
                            keys: new Set([updatedRowKey]),
                            metadata: [updatedRowMetaData]
                        }
                    });
                    this.itemsDataProvider.refresh();
                }
                ;
                document.getElementById("editDialog").close();
            });
            this.deleteItem = (event) => __awaiter(this, void 0, void 0, function* () {
                let itemID = this.firstSelectedItem().data.id;
                const currentRow = this.selectedRow;
                if (currentRow != null) {
                    let really = confirm("Are you sure you want to delete this item?");
                    if (really) {
                        const request = new Request(`${this.restServerURLItems}${itemID}`, { method: "DELETE" });
                        const response = yield fetch(request);
                        if (response.status === 200) {
                            const removedRowKey = itemID;
                            const removedRowMetaData = { key: removedRowKey };
                            this.itemsDataProvider.mutate({
                                remove: {
                                    data: [itemID],
                                    keys: new Set([removedRowKey]),
                                    metadata: [removedRowMetaData],
                                },
                            });
                            this.itemsDataProvider.refresh();
                        }
                        else {
                            alert("Delete failed with status " + response.status + " : " + response.statusText);
                        }
                    }
                }
            });
            /**
            * Handle selection from Activity Items list
            */
            this.selectedItemChanged = (event) => {
                // debugger
                let isClicked = event.detail.value.data;
                if (isClicked != null) {
                    // debugger
                    // If selection, populate and display list
                    this.selectedData(event.detail.value.data); //cambiar a selectedData, y selectedKeyItem cambiar a selectedKeyItem
                    this.currentItem(this.selectedData());
                    // Create variable and get attributes of the items list to set pie chart values
                    let pieSeries = [
                        { name: "Quantity in Stock", items: [this.selectedData().quantity_instock] },
                        { name: "Quantity Shipped", items: [this.selectedData().quantity_shipped] }
                    ];
                    // Update the pie chart with the data
                    this.pieSeriesValue(pieSeries);
                    this.itemSelected(true);
                }
                else {
                    // If deselection, hide list
                    // debugger
                    this.itemSelected(false);
                }
            };
            this.activityDataProvider = new ojrestdataprovider_1.RESTDataProvider({
                keyAttributes: this.keyAttributes,
                url: this.restServerURLActivities,
                transforms: {
                    fetchFirst: {
                        request: (options) => __awaiter(this, void 0, void 0, function* () {
                            // debugger
                            const url = new URL(options.url);
                            const { size, offset } = options.fetchParameters;
                            url.searchParams.set("limit", String(size));
                            url.searchParams.set("offset", String(offset));
                            return new Request(url.href);
                        }),
                        response: ({ body }) => __awaiter(this, void 0, void 0, function* () {
                            // debugger
                            const { items, totalSize, hasMore } = body;
                            return { data: items, totalSize, hasMore };
                        })
                    }
                }
            });
            // this.activityDataProvider
            // let activitiesArray = JSON.parse(storeData);
            // let itemsArray = activitiesArray[0].items;
            this.selectedData = ko.observable('');
            this.pieSeriesValue = ko.observableArray([]);
            let pieSeries = [
                { name: "Quantity in Stock", items: [this.selectedData().quantity_instock] },
                { name: "Quantity Shipped", items: [this.selectedData().quantity_shipped] }
            ];
            this.pieSeriesValue(pieSeries);
            this.itemName = ko.observable();
            this.price = ko.observable();
            this.short_desc = ko.observable();
            this.quantity_instock = ko.observable();
            this.quantity_shipped = ko.observable();
            this.quantity = 0;
            this.inputItemID = ko.observable();
            this.inputItemName = ko.observable();
            this.inputPrice = ko.observable();
            this.inputShortDescription = ko.observable();
            //
            this.useCase = ko.observable('');
            //
            this.currentItem = ko.observable(Object.assign({}, emptyItem));
            // this.currentItemSubscription= this.currentItem.subscribe((data)=>{
            //   debugger
            // })
        }
        /**
         * Optional ViewModel method invoked after the View is inserted into the
         * document DOM.  The application can put logic that requires the DOM being
         * attached here.
         * This method might be called multiple times - after the View is created
         * and inserted into the DOM and after the View is reconnected
         * after being disconnected.
         */
        connected() {
            AccUtils.announce("Dashboard page loaded.");
            document.title = "Dashboard";
            // implement further logic if needed
        }
        /**
         * Optional ViewModel method invoked after the View is disconnected from the DOM.
         */
        disconnected() {
            // implement if needed
        }
        /**
         * Optional ViewModel method invoked after transition to the new View is complete.
         * That includes any possible animation between the old and the new View.
         */
        transitionCompleted() {
            // implement if needed
        }
    }
    return DashboardViewModel;
});
//# sourceMappingURL=dashboard.js.map