var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define(["require", "exports", "../accUtils", "knockout", "ojs/ojknockout-keyset", "ojs/ojmodel", "ojs/ojcollectiondataprovider", "ojs/ojselectsingle", "ojs/ojchart", "ojs/ojlabel", "ojs/ojlistview", "ojs/ojavatar", "ojs/ojdialog", "ojs/ojinputtext", "demo-update-item/loader"], function (require, exports, AccUtils, ko, ojknockout_keyset_1, ojmodel_1, CollectionDataProvider) {
    "use strict";
    const emptyItem = {
        id: 0,
        name: '',
        short_desc: '',
        price: 0,
        quantity: 0,
        quantity_shipped: 0,
        quantity_instock: 0,
        activity_id: 0,
        image: ''
    };
    class CustomersViewModel {
        constructor() {
            var _a, _b;
            //  Fields for delete button and update dialog, among others
            this.selectedRow = ko.observable();
            this.inputImageFile = 'css/images/product_images/jet_logo_256.png';
            this.keyAttributes = "id";
            this.activityKey = 1;
            this.restServerURLActivities = "https://apex.oracle.com/pls/apex/oraclejet/lp/activities/";
            this.restServerURLItems = "https://apex.oracle.com/pls/apex/oraclejet/lp/activities/" + this.activityKey + "/items/";
            this.selectedActivity = new ojknockout_keyset_1.ObservableKeySet();
            this.activitySelected = ko.observable(false);
            this.firstSelectedActivity = ko.observable();
            //selectedActivityIds = ko.observable();
            this.itemSelected = ko.observable(false);
            this.selectedKeyItem = ko.observable();
            this.firstSelectedItem = ko.observable();
            this.parseActivity = (response) => {
                return {
                    id: response["id"],
                    name: response["name"],
                    image: response["image"],
                    short_desc: response["short_desc"],
                };
            };
            this.parseSaveActivity = (response) => {
                return {
                    id: response["id"],
                    name: response["name"],
                    image: response["image"],
                    short_desc: response["short_desc"],
                };
            };
            this.parseItem = (response) => {
                return {
                    id: response["id"],
                    activity_id: response["activity_id"],
                    name: response["name"],
                    price: response["price"],
                    description: response["description"],
                    image: response["image"],
                    quantity_shipped: response["quantity_shipped"],
                    quantity_instock: response["quantity_instock"],
                };
            };
            this.parseSaveItem = (response) => {
                return {
                    id: response["id"],
                    name: response["name"],
                    price: response["price"],
                    description: response["description"],
                    image: response["image"],
                    activity_id: response["activity_id"],
                    quantity_shipped: response["quantity_shipped"],
                    quantity_instock: response["quantity_instock"],
                };
            };
            this.Activity = ojmodel_1.Model.extend({
                parse: this.parseActivity,
                parseSave: this.parseSaveActivity,
                idAttribute: "id",
            });
            this.Item = ojmodel_1.Model.extend({
                parse: this.parseItem,
                parseSave: this.parseSaveItem,
                idAttribute: "id",
            });
            this.myActivity = new this.Activity();
            this.myItem = new this.Item();
            this.ItemCollection = ojmodel_1.Collection.extend({
                url: "https://apex.oracle.com/pls/apex/oraclejet/lp/activities/" + "0" + "/items/",
                model: this.myItem,
                comparator: 'id'
            });
            this.ActivityCollection = ojmodel_1.Collection.extend({
                url: this.restServerURLActivities,
                model: this.myActivity,
                comparator: 'id'
            });
            this.selectedActivityChanged = (event) => {
                /**
                *  If no items are selected then the firstSelectedItem property  returns an object
                *  with both key and data properties set to null.
                */
                let activityContext = event.detail.value.data;
                if (activityContext != null) {
                    this.activitySelected(false);
                    this.activityKey = event.detail.value.data.id;
                    //hacer el fetch de los items
                    // observable de items?
                    //FETCH DEL MODEL ITEM
                    //let itemCollection = new ItemCollection();
                    this.itemCollection.url = "https://apex.oracle.com/pls/apex/oraclejet/lp/activities/" + this.activityKey + "/items/";
                    this.itemCollection.fetch({
                        success: (collection) => {
                            //this.itemsObservable(collection);
                            //this.itemCollectionDataProvider(new CollectionDataProvider<number, Item>(this.itemsObservable()));
                        }
                    });
                    this.activitySelected(true);
                    this.itemSelected(false);
                    this.selectedKeyItem();
                    //this.selectedData();
                }
                else {
                    // debugger
                    // If deselection, hide list      
                    this.activitySelected(false);
                    this.itemSelected(false);
                }
            };
            this.showCreateDialog = (event) => {
                //Observable de useCase
                this.useCase('create');
                //Inicializar observable de currentItem
                this.currentItem(Object.assign(Object.assign({}, emptyItem), { activity_id: this.firstSelectedActivity().data.id }));
                let x = document.getElementById("createDialog");
                let y = x;
                y.open();
            };
            this.createItem = (event) => __awaiter(this, void 0, void 0, function* () {
                debugger;
                //AQUÍ debo actualizar el observable this.currentItem()
                //this.currentItem(this.selectedData())
                let a = Number(this.currentItem().quantity_instock);
                let b = Number(this.currentItem().quantity_shipped);
                //Con esto cogemos el model que está usando nuestra collection y clona la "plantilla"
                const itemModel = this.itemCollection.model.clone();
                //Alternativa: coger la colección y hacer un create
                // (this.itemCollection as Collection).create({
                // name: this.currentItem().name,
                // short_desc: this.currentItem().short_desc,
                // price: this.currentItem().price,
                // quantity_instock: a,
                // quantity_shipped: b,
                // quantity: a+b,
                // activity_id: this.currentItem().activity_id
                // })
                //const itemToCreate = this.Item.extend()
                itemModel.save({
                    id: undefined,
                    name: this.currentItem().name,
                    price: this.currentItem().price,
                    description: this.currentItem().short_desc,
                    quantity_instock: a,
                    quantity_shipped: b,
                    quantity: a + b,
                    activity_id: this.currentItem().activity_id
                }, {
                    success: () => {
                        debugger;
                        this.itemCollection.refresh();
                    }
                });
                //close
                let x = document.getElementById("createDialog");
                let y = x;
                y.close();
            });
            this.showEditDialog = (event) => {
                //Observable de useCase
                this.useCase('update');
                //Observable of currentItem
                const item = this.firstSelectedItem().data;
                this.currentItem(Object.assign({}, item));
                document.getElementById("editDialog").open();
            };
            this.updateItemSubmit = (event) => __awaiter(this, void 0, void 0, function* () {
                var _c;
                let itemID = (_c = this.firstSelectedItem()) === null || _c === void 0 ? void 0 : _c.data.id;
                const currentRow = this.selectedRow;
                debugger;
                if (currentRow != null) {
                    const itemToUpdate = this.itemCollection.get(itemID);
                    console.log(itemToUpdate);
                    itemToUpdate.set({
                        id: this.currentItem().id,
                        name: this.currentItem().name,
                        price: this.currentItem().price,
                        description: this.currentItem().short_desc
                    }, {
                        success: () => { }
                    });
                    // const request = new Request(
                    //   `${this.restServerURLItems}${this.currentItem().id}`,
                    //   {
                    //     headers: new Headers({
                    //       "Content-type": "application/json; charset=UTF-8",
                    //     }),
                    //     body: JSON.stringify(itemToUpdate),
                    //     method: "PUT",
                    //   }
                    // );
                    // const response = await fetch(request)
                    // const updatedRow = await response.json()
                    // const updatedRowKey = this.currentItem().id;
                    // const updatedRowMetaData = { key: updatedRowKey}
                    // this.itemsDataProvider.mutate({
                    //   update: {
                    //     data: [updatedRow],
                    //     keys: new Set([updatedRowKey]),
                    //     metadata: [updatedRowMetaData]
                    //   }
                    // })
                    // this.itemsDataProvider.refresh()
                }
                ;
                document.getElementById("editDialog").close();
            });
            this.deleteItem = (event) => __awaiter(this, void 0, void 0, function* () {
                var _d;
                let itemID = (_d = this.firstSelectedItem()) === null || _d === void 0 ? void 0 : _d.data.id;
                const currentRow = this.selectedRow;
                if (currentRow != null) {
                    debugger;
                    let really = confirm("Are you sure you want to delete this item?");
                    if (really) {
                        const itemToDelete = this.itemCollection.get(itemID).clone();
                        //itemToDelete.url((this.itemCollection.url as string).concat("/").concat(itemID));
                        itemToDelete.destroy({
                            success: () => {
                                this.itemCollection.remove(itemToDelete);
                                this.itemCollection.refresh();
                            }
                        });
                    }
                }
            });
            /**
            * Handle selection from Activity Items list
            */
            this.selectedItemChanged = (event) => {
                // debugger
                let isClicked = event.detail.value.data;
                if (isClicked != null) {
                    // debugger
                    // If selection, populate and display list
                    // Create variable and get attributes of the items list to set pie chart values
                    let pieSeries = [
                        { name: "Quantity in Stock", items: [isClicked.quantity_instock] },
                        { name: "Quantity Shipped", items: [isClicked.quantity_shipped] }
                    ];
                    // Update the pie chart with the data
                    this.pieSeriesValue(pieSeries);
                    this.itemSelected(true);
                }
                else {
                    // If deselection, hide list
                    this.itemSelected(false);
                }
            };
            this.pieSeriesValue = ko.observableArray([]);
            let pieSeries = [
                { name: "Quantity in Stock", items: [(_a = this.firstSelectedItem()) === null || _a === void 0 ? void 0 : _a.data.quantity_instock] },
                { name: "Quantity Shipped", items: [(_b = this.firstSelectedItem()) === null || _b === void 0 ? void 0 : _b.data.quantity_shipped] }
            ];
            this.pieSeriesValue(pieSeries);
            this.quantity = 0;
            //
            this.useCase = ko.observable('');
            //
            this.currentItem = ko.observable(Object.assign({}, emptyItem));
            //Dataprovider exercise
            //hacer fetch de actividades e items para mi activity data provider
            this.itemsObservable = ko.observable(new ojmodel_1.Collection());
            let actCollection = new this.ActivityCollection();
            actCollection.fetch({
                success: () => {
                    //debugger
                    //let koObjActivity = (KnockoutUtils.map(this.myActivity) as unknown as Activity);
                    //this.currentItem(koObjActivity);
                    this.activitiesObservable(actCollection);
                },
            });
            this.activitiesObservable = ko.observable(actCollection);
            this.activityCollectionDataProvider = ko.observable(new CollectionDataProvider(this.activitiesObservable()));
            this.itemCollection = new this.ItemCollection();
            this.itemCollectionDataProvider = ko.observable(new CollectionDataProvider(this.itemCollection));
            //debugger
            this.myActivity.urlRoot = this.restServerURLActivities;
            this.myItem.urlRoot = this.restServerURLItems;
        }
        /**
         * Optional ViewModel method invoked after the View is inserted into the
         * document DOM.  The application can put logic that requires the DOM being
         * attached here.
         * This method might be called multiple times - after the View is created
         * and inserted into the DOM and after the View is reconnected
         * after being disconnected.
         */
        connected() {
            AccUtils.announce("Dashboard page loaded.");
            document.title = "Dashboard";
        }
        /**
         * Optional ViewModel method invoked after the View is disconnected from the DOM.
         */
        disconnected() {
            // implement if needed
        }
        /**
         * Optional ViewModel method invoked after transition to the new View is complete.
         * That includes any possible animation between the old and the new View.
         */
        transitionCompleted() {
            // implement if needed
        }
    }
    return CustomersViewModel;
});
//# sourceMappingURL=customers.js.map