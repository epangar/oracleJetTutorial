/// <reference types="ojcollectiondataprovider" />
import * as ko from "knockout";
import "ojs/ojselectsingle";
import "ojs/ojchart";
import "ojs/ojlabel";
import "ojs/ojlistview";
import "ojs/ojavatar";
import 'ojs/ojdialog';
import 'ojs/ojinputtext';
import { ObservableKeySet } from "ojs/ojknockout-keyset";
import { ojListView } from "ojs/ojlistview";
import { RESTDataProvider } from "ojs/ojrestdataprovider";
import { ojButtonEventMap } from 'ojs/ojbutton';
import "demo-update-item/loader";
import { Collection } from 'ojs/ojmodel';
import CollectionDataProvider = require("ojs/ojcollectiondataprovider");
declare type Activity = {
    id: number;
};
declare type Item = {
    id: number;
    name: string;
    short_desc: string;
    price: number;
    quantity: number;
    quantity_shipped: number;
    quantity_instock: number;
    activity_id: number;
    image: string;
};
declare type ActivityItems = {
    id: number;
    name: string;
    items: Array<Item>;
    short_desc: string;
    image: string;
};
declare class CustomersViewModel {
    currentItem: ko.Observable<Item>;
    useCase: ko.Observable<string>;
    selectedRow: ko.Observable<number>;
    quantity: number;
    inputImageFile: string;
    keyAttributes: string;
    activityKey: number;
    restServerURLActivities: string;
    itemsDataProvider: RESTDataProvider<Item["id"], Item>;
    restServerURLItems: string;
    itemsArray: Array<Object>;
    pieSeriesValue: ko.ObservableArray;
    selectedActivity: ObservableKeySet<unknown>;
    activitySelected: ko.Observable<boolean>;
    firstSelectedActivity: ko.Observable<any>;
    selectedActivityIds: ko.Observable<any>;
    itemSelected: ko.Observable<boolean>;
    selectedKeyItem: ko.Observable<any>;
    firstSelectedItem: ko.Observable<any>;
    activitiesObservable: ko.Observable<Collection>;
    activityCollectionDataProvider: ko.Observable<CollectionDataProvider<number, Activity>>;
    private parseActivity;
    private parseSaveActivity;
    private parseItem;
    private parseSaveItem;
    Activity: any;
    Item: any;
    myActivity: any;
    myItem: any;
    private ItemCollection;
    private ActivityCollection;
    myData: ko.Observable<any>;
    constructor();
    selectedActivityChanged: (event: ojListView.firstSelectedItemChanged<ActivityItems["id"], ActivityItems>) => void;
    showCreateDialog: (event: ojButtonEventMap["ojAction"]) => void;
    createItem: (event: ojButtonEventMap["ojAction"]) => Promise<void>;
    showEditDialog: (event: ojButtonEventMap["ojAction"]) => void;
    updateItemSubmit: (event: ojButtonEventMap["ojAction"]) => Promise<void>;
    deleteItem: (event: ojButtonEventMap["ojAction"]) => Promise<void>;
    /**
    * Handle selection from Activity Items list
    */
    selectedItemChanged: (event: ojListView.firstSelectedItemChanged<Item["id"], Item>) => void;
    /**
     * Optional ViewModel method invoked after the View is inserted into the
     * document DOM.  The application can put logic that requires the DOM being
     * attached here.
     * This method might be called multiple times - after the View is created
     * and inserted into the DOM and after the View is reconnected
     * after being disconnected.
     */
    connected(): void;
    /**
     * Optional ViewModel method invoked after the View is disconnected from the DOM.
     */
    disconnected(): void;
    /**
     * Optional ViewModel method invoked after transition to the new View is complete.
     * That includes any possible animation between the old and the new View.
     */
    transitionCompleted(): void;
}
export = CustomersViewModel;
