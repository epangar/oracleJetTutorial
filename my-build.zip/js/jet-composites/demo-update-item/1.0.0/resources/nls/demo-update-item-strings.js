define(["require", "exports"], function (require, exports) {
    "use strict";
    return {
        "root": {
            "demo-update-item": {
                "sampleString": "The strings file can be used to manage translatable resources"
            }
        },
    };
});
//# sourceMappingURL=demo-update-item-strings.js.map