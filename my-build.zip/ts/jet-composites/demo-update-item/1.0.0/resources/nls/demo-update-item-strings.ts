export = {
 "root": {
  "demo-update-item": {
    "sampleString": "The strings file can be used to manage translatable resources"
  }
 },
};