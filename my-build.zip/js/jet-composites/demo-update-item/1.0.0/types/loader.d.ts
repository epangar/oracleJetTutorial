import "css!./demo-update-item-styles.css";
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            "demo-update-item": any;
        }
    }
}
