var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define(["require", "exports", "../accUtils", "knockout", "ojs/ojknockout-keyset", "ojs/ojrestdataprovider", "ojs/ojselectsingle", "ojs/ojchart", "ojs/ojlabel", "ojs/ojlistview", "ojs/ojavatar", "ojs/ojdialog", "ojs/ojinputtext", "demo-update-item/loader"], function (require, exports, AccUtils, ko, ojknockout_keyset_1, ojrestdataprovider_1) {
    "use strict";
    const emptyItem = {
        id: 0,
        name: '',
        short_desc: '',
        price: 0,
        quantity: 0,
        quantity_shipped: 0,
        quantity_instock: 0,
        activity_id: 0,
        image: ''
    };
    class DashboardViewModel {
        constructor() {
            var _a, _b;
            //  Fields for delete button and update dialog, among others
            this.selectedRow = ko.observable();
            this.inputImageFile = 'css/images/product_images/jet_logo_256.png';
            this.keyAttributes = "id";
            this.activityKey = 3;
            this.restServerURLActivities = "https://apex.oracle.com/pls/apex/oraclejet/lp/activities/";
            this.restServerURLItems = "https://apex.oracle.com/pls/apex/oraclejet/lp/activities/" + this.activityKey + "/items/";
            this.selectedActivity = new ojknockout_keyset_1.ObservableKeySet();
            this.activitySelected = ko.observable(false);
            this.firstSelectedActivity = ko.observable();
            this.selectedActivityIds = ko.observable();
            this.itemSelected = ko.observable(false);
            this.selectedKeyItem = ko.observable();
            this.firstSelectedItem = ko.observable();
            this.selectedActivityChanged = (event) => {
                /**
                *  If no items are selected then the firstSelectedItem property  returns an object
                *  with both key and data properties set to null.
                */
                //  debugger
                let itemContext = event.detail.value.data;
                if (itemContext != null) {
                    this.activitySelected(false);
                    this.activityKey = event.detail.value.data.id;
                    this.restServerURLItems = "https://apex.oracle.com/pls/apex/oraclejet/lp/activities/" + this.activityKey + "/items/";
                    this.itemsDataProvider = new ojrestdataprovider_1.RESTDataProvider({
                        keyAttributes: this.keyAttributes,
                        url: this.restServerURLItems,
                        transforms: {
                            fetchFirst: {
                                request: (options) => __awaiter(this, void 0, void 0, function* () {
                                    // debugger
                                    const url = new URL(options.url);
                                    const { size, offset } = options.fetchParameters;
                                    url.searchParams.set("limit", String(size));
                                    url.searchParams.set("offset", String(offset));
                                    return new Request(url.href);
                                }),
                                response: ({ body }) => __awaiter(this, void 0, void 0, function* () {
                                    // debugger
                                    const { items, totalSize, hasMore } = body;
                                    return { data: items, totalSize, hasMore };
                                }),
                            },
                        },
                    });
                    this.activitySelected(true);
                    this.itemSelected(false);
                    this.selectedKeyItem();
                    //this.selectedData();
                }
                else {
                    // debugger
                    // If deselection, hide list      
                    this.activitySelected(false);
                    this.itemSelected(false);
                }
            };
            this.showCreateDialog = (event) => {
                //Observable de useCase
                this.useCase('create');
                //Inicializar observable de currentItem
                this.currentItem(Object.assign(Object.assign({}, emptyItem), { activity_id: this.firstSelectedActivity().data.id }));
                let x = document.getElementById("createDialog");
                let y = x;
                y.open();
            };
            this.createItem = (event) => __awaiter(this, void 0, void 0, function* () {
                //debugger
                //AQUÍ debo actualizar el observable this.currentItem()
                console.log(event);
                //this.currentItem(this.selectedData())
                let a = Number(this.currentItem().quantity_instock);
                let b = Number(this.currentItem().quantity_shipped);
                const request = new Request(this.restServerURLItems, {
                    headers: new Headers({
                        "Content-type": "application/json; charset=UTF-8",
                    }),
                    body: JSON.stringify(this.currentItem()),
                    method: "POST"
                });
                const response = yield fetch(request);
                const addedRow = yield response.json();
                const addedRowKey = addedRow[this.keyAttributes];
                const addedRomMetaData = { key: addedRowKey };
                this.itemsDataProvider.mutate({
                    add: {
                        data: [addedRow],
                        keys: new Set([addedRowKey]),
                        metadata: [addedRomMetaData]
                    }
                });
                this.itemsDataProvider.refresh();
                //close
                let x = document.getElementById("createDialog");
                let y = x;
                y.close();
            });
            this.showEditDialog = (event) => {
                //Observable de useCase
                this.useCase('update');
                //Observable of currentItem
                //debugger
                const item = this.firstSelectedItem().data;
                this.currentItem(Object.assign({}, item));
                document.getElementById("editDialog").open();
            };
            this.updateItemSubmit = (event) => __awaiter(this, void 0, void 0, function* () {
                const currentRow = this.selectedRow;
                //debugger
                if (currentRow != null) {
                    const itemToUpdate = {
                        itemId: this.currentItem().id,
                        name: this.currentItem().name,
                        price: this.currentItem().price,
                        short_desc: this.currentItem().short_desc
                    };
                    const request = new Request(`${this.restServerURLItems}${this.currentItem().id}`, {
                        headers: new Headers({
                            "Content-type": "application/json; charset=UTF-8",
                        }),
                        body: JSON.stringify(itemToUpdate),
                        method: "PUT",
                    });
                    const response = yield fetch(request);
                    const updatedRow = yield response.json();
                    const updatedRowKey = this.currentItem().id;
                    const updatedRowMetaData = { key: updatedRowKey };
                    this.itemsDataProvider.mutate({
                        update: {
                            data: [updatedRow],
                            keys: new Set([updatedRowKey]),
                            metadata: [updatedRowMetaData]
                        }
                    });
                    this.itemsDataProvider.refresh();
                }
                ;
                document.getElementById("editDialog").close();
            });
            this.deleteItem = (event) => __awaiter(this, void 0, void 0, function* () {
                var _c;
                let itemID = (_c = this.firstSelectedItem()) === null || _c === void 0 ? void 0 : _c.data.id;
                const currentRow = this.selectedRow;
                if (currentRow != null) {
                    let really = confirm("Are you sure you want to delete this item?");
                    if (really) {
                        const request = new Request(`${this.restServerURLItems}${itemID}`, { method: "DELETE" });
                        const response = yield fetch(request);
                        if (response.status === 200) {
                            const removedRowKey = itemID;
                            const removedRowMetaData = { key: removedRowKey };
                            this.itemsDataProvider.mutate({
                                remove: {
                                    data: [itemID],
                                    keys: new Set([removedRowKey]),
                                    metadata: [removedRowMetaData],
                                },
                            });
                            this.itemsDataProvider.refresh();
                        }
                        else {
                            alert("Delete failed with status " + response.status + " : " + response.statusText);
                        }
                    }
                }
            });
            /**
            * Handle selection from Activity Items list
            */
            this.selectedItemChanged = (event) => {
                let isClicked = event.detail.value.data;
                if (isClicked != null) {
                    //debugger
                    // If selection, populate and display list
                    // Create variable and get attributes of the items list to set pie chart values
                    let pieSeries = [
                        { name: "Quantity in Stock", items: [isClicked.quantity_instock] },
                        { name: "Quantity Shipped", items: [isClicked.quantity_shipped] }
                    ];
                    // Update the pie chart with the data
                    this.pieSeriesValue(pieSeries);
                    this.itemSelected(true);
                }
                else {
                    // If deselection, hide list
                    this.itemSelected(false);
                }
            };
            this.activityDataProvider = new ojrestdataprovider_1.RESTDataProvider({
                keyAttributes: this.keyAttributes,
                url: this.restServerURLActivities,
                transforms: {
                    fetchFirst: {
                        request: (options) => __awaiter(this, void 0, void 0, function* () {
                            // debugger
                            const url = new URL(options.url);
                            const { size, offset } = options.fetchParameters;
                            url.searchParams.set("limit", String(size));
                            url.searchParams.set("offset", String(offset));
                            return new Request(url.href);
                        }),
                        response: ({ body }) => __awaiter(this, void 0, void 0, function* () {
                            // debugger
                            const { items, totalSize, hasMore } = body;
                            return { data: items, totalSize, hasMore };
                        })
                    }
                }
            });
            this.pieSeriesValue = ko.observableArray([]);
            let pieSeries = [
                { name: "Quantity in Stock", items: [(_a = this.firstSelectedItem()) === null || _a === void 0 ? void 0 : _a.data.quantity_instock] },
                { name: "Quantity Shipped", items: [(_b = this.firstSelectedItem()) === null || _b === void 0 ? void 0 : _b.data.quantity_shipped] }
            ];
            this.pieSeriesValue(pieSeries);
            this.quantity = 0;
            //
            this.useCase = ko.observable('');
            //
            this.currentItem = ko.observable(Object.assign({}, emptyItem));
        }
        /**
         * Optional ViewModel method invoked after the View is inserted into the
         * document DOM.  The application can put logic that requires the DOM being
         * attached here.
         * This method might be called multiple times - after the View is created
         * and inserted into the DOM and after the View is reconnected
         * after being disconnected.
         */
        connected() {
            AccUtils.announce("Dashboard page loaded.");
            document.title = "Dashboard";
            // implement further logic if needed
        }
        /**
         * Optional ViewModel method invoked after the View is disconnected from the DOM.
         */
        disconnected() {
            // implement if needed
        }
        /**
         * Optional ViewModel method invoked after transition to the new View is complete.
         * That includes any possible animation between the old and the new View.
         */
        transitionCompleted() {
            // implement if needed
        }
    }
    return DashboardViewModel;
});
//# sourceMappingURL=dashboard.js.map