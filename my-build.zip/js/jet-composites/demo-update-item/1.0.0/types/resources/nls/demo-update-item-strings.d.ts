declare const _default: {
    root: {
        "demo-update-item": {
            sampleString: string;
        };
    };
};
export = _default;
