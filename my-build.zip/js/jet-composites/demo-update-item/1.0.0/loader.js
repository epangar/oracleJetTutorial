define(["require", "exports", "ojs/ojcomposite", "text!./demo-update-item-view.html", "./demo-update-item-viewModel", "text!./component.json", "css!./demo-update-item-styles.css"], function (require, exports, Composite, view, demo_update_item_viewModel_1, metadata) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    Composite.register("demo-update-item", {
        view: view,
        viewModel: demo_update_item_viewModel_1.default,
        metadata: JSON.parse(metadata)
    });
});
//# sourceMappingURL=loader.js.map