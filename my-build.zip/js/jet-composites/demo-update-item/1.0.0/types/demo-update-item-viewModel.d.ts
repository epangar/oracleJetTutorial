/// <reference types="ojasyncvalidator-length" />
import * as ko from "knockout";
import Composite = require("ojs/ojcomposite");
import "ojs/ojknockout";
import "ojs/ojformlayout";
import "ojs/ojinputtext";
import "ojs/ojlabelvalue";
import { IntlNumberConverter } from "ojs/ojconverter-number";
import AsyncLengthValidator = require("ojs/ojasyncvalidator-length");
declare type Item = {
    id: number;
    name: string;
    short_desc: string;
    price: number;
    quantity: number;
    quantity_shipped: number;
    quantity_instock: number;
    activity_id: number;
    image: string;
};
interface MyProperties {
    useCase: string;
    item: ko.Observable<Item>;
}
export default class ViewModel implements Composite.ViewModel<MyProperties> {
    busyResolve: (() => void);
    composite: Element;
    messageText: ko.Observable<string>;
    properties: MyProperties;
    res: {
        [key: string]: string;
    };
    smallQuery: string;
    isSmall: ko.Observable;
    labelEdge: ko.Computed;
    currency: IntlNumberConverter;
    lengthValue1: ko.Observable<string>;
    validators: ko.ObservableArray<AsyncLengthValidator<string>>;
    isUpdate: boolean;
    myObservable: ko.Observable<Item>;
    constructor(context: Composite.ViewModelContext<MyProperties>);
    activated(context: Composite.ViewModelContext<MyProperties>): Promise<any> | void;
    connected(context: Composite.ViewModelContext<MyProperties>): void;
    bindingsApplied(context: Composite.ViewModelContext<MyProperties>): void;
    propertyChanged: (context: Composite.PropertyChangedContext<MyProperties>) => void;
    disconnected(element: Element): void;
}
export {};
